const express = require('express');
const app = express();
const server = require('http').Server(app);
const io = require('socket.io')(server);
const port = 80;

server.listen(port, () => console.log(`Server started on port ${port}`));

app.use(express.static('./chess/'));

io.on('connection', function (socket) {
    socket.emit('boardInit', { hello: 'world' });
    // socket.on('getBoard', function (data) {
    //     console.log(data);
    // });
});