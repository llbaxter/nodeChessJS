const board = document.getElementById('board');
for (let i = 0; i < 64; i++) {
  let tile = document.createElement('div');
  tile.classList += 'tile' + (i + ~~(i/8)) % 2;
  tile.id = `${i % 8}_${~~(i / 8)}`;
  // tile.innerText = i;

  
  let overlay = document.createElement('div');
  overlay.id = tile.id + '_overlay';
  overlay.classList.add('overlay');
  tile.appendChild(overlay);

  board.appendChild(tile);
}

pieces = {'wp': 1};
function addPiece(type, col, x, y) {
    let name = type + col;
    let p = document.createElement('img');
    p.src = `images/${name}.png`;
    let num = 0;
    if (pieces[name] === undefined) {
        pieces[name] = 0;
    } else {
        num = pieces[name]++;
    }
    p.id = name + num;
    p.classList += 'piece';
    p.style.marginTop = y * 64 + 'px';
    p.style.marginLeft = x * 64 + 'px';

    board.appendChild(p);
    return p;
}

// addPiece('wr', 0, 0, 0);
// addPiece('wr', 7, 0, 1);
// addPiece('wn', 1, 0, 0);
// addPiece('wn', 6, 0, 1);
// addPiece('wb', 2, 0, 0);
// addPiece('wb', 5, 0, 1);
// addPiece('wq', 4, 0);
// addPiece('wk', 3, 0);

// for (let i = 0; i < 8; i++) {
//     addPiece('wp', i, 1, i);
// }

// addPiece('br', 0, 7, 0);
// addPiece('br', 7, 7, 1);
// addPiece('bn', 1, 7, 0);
// addPiece('bn', 6, 7, 1);
// addPiece('bb', 2, 7, 0);
// addPiece('bb', 5, 7, 1);
// addPiece('bq', 4, 7);
// addPiece('bk', 3, 7);

// for (let i = 0; i < 8; i++) {
//     addPiece('bp', i, 6, i);
// }


//timer
function startTimer(duration, display) {
  var start = Date.now(),
      diff,
      minutes,
      seconds;
  function timer() {
      // get the number of seconds that have elapsed since 
      // startTimer() was called
      diff = duration - (((Date.now() - start) / 1000) | 0);

      // does the same job as parseInt truncates the float
      minutes = (diff / 60) | 0;
      seconds = (diff % 60) | 0;

      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      display.textContent = minutes + ":" + seconds; 

      if (diff <= 0) {
          // add one second so that the count down starts at the full duration
          // example 05:00 not 04:59
          start = Date.now() + 1000;
      }
  };
  // we don't want to wait a full second before the timer starts
  timer();
  setInterval(timer, 1000);
}

window.onload = function () {
  var fiveMinutes = 60 * 5,
      display = document.querySelector('#time');
      
  startTimer(fiveMinutes, display);
};