const height = board.height;
const width = board.width;

const piece = {KING: 'k', QUEEN: 'q', BISHOP: 'b', KNIGHT: 'n', ROOK: 'r', PAWN: 'p'};
const player = {WHITE: 'w', BLACK: 'b'};


class Piece {
    constructor(type, col, board, x, y) {
        this.type = type;
        this.col = col;
        this.board = board;
        this.x = x;
        this.y = y;
        this.board.set(x, y, this);
        this.moved = false;
        this.image = addPiece(col, type, x, y);
    }

    move(x, y) {
        this.board.set(this.x, this.y, null);
        this.x = x;
        this.y = y;
        this.image.style.marginTop = y * 64 + 'px';
        this.image.style.marginLeft = x * 64 + 'px';
        this.board.set(this.x, this.y, this);
        this.moved = true;
    }

    getMoves() {
        let moves = [];
        // let taken = [];
        let x = this.x;
        let y = this.y;
        if (this.type === piece.PAWN) {
            if (this.col == player.WHITE) {
                if (this.board.isEmpty(x, y-1)) {
                    moves.push([x, y-1]);

                    if (!this.moved && this.board.isEmpty(x, y-2)) {
                        moves.push([x, y-2]);                        
                    }
                }

                if (this.board.isBlack(x+1, y-1)) {
                    moves.push([x+1, y-1]);
                }
                if (this.board.isBlack(x-1, y-1)) {
                    moves.push([x-1, y-1]);
                }


            } else {
                if (this.board.isEmpty(x, y+1)) {
                    moves.push([x, y+1]);

                    if (!this.moved && this.board.isEmpty(x, y+2)) {
                        moves.push([x, y+2]);                        
                    }
                }

                if (this.board.isWhite(x+1, y+1)) {
                    moves.push([x+1, y+1]);
                }
                if (this.board.isWhite(x-1, y+1)) {
                    moves.push([x-1, y+1]);
                }


            }
        } else if (this.type === piece.BISHOP) {
            if (this.col == player.WHITE) {
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
            } else {
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
            }
        } else if (this.type === piece.KNIGHT) {
            const o = [[1, -1], [2, -2]];
            if (this.col == player.WHITE) {
                for (let p of [0, 1]) {
                    for (let i of o[p]) {
                        for (let j of o[+!p]) {
                            let a = x + i;
                            let b = y + j;

                            if (this.board.in(a, b) && (this.board.isEmpty(a, b) || this.board.isBlack(a, b))) {
                                moves.push([a, b]);
                            } 
                        }
                    }
                }
            } else {
                for (let p of [0, 1]) {
                    for (let i of o[p]) {
                        for (let j of o[+!p]) {
                            let a = x + i;
                            let b = y + j;

                            if (this.board.in(a, b) && (this.board.isEmpty(a, b) || this.board.isWhite(a, b))) {
                                moves.push([a, b]);
                            } 
                        }
                    }
                }
            }
        } else if (this.type === piece.ROOK) {
            if (this.col == player.WHITE) {
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }

                for (let i = 1; i <= 7; i++) {
                    let a = x;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
            } else {
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }

                for (let i = 1; i <= 7; i++) {
                    let a = x;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }

                
            }
        } else if (this.type === piece.QUEEN) {
            if (this.col == player.WHITE) {
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }


                // Rook
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }

                for (let i = 1; i <= 7; i++) {
                    let a = x;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isWhite(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isBlack(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
            } else {
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }

                // Rook
                for (let i = 1; i <= 7; i++) {
                    let a = x + i;
                    let b = y;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x - i;
                    let b = y;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }

                for (let i = 1; i <= 7; i++) {
                    let a = x;
                    let b = y + i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
                for (let i = 1; i <= 7; i++) {
                    let a = x;
                    let b = y - i;
                    if (!this.board.in(a, b) || this.board.isBlack(a, b)) break;

                    if (this.board.isEmpty(a, b)) {
                        moves.push([a, b]);
                    } else if (this.board.isWhite(a, b)) {
                        moves.push([a, b]);
                        break;
                    }
                }
            }
        } else if (this.type === piece.KING) {
            if (this.col == player.WHITE) {
                for (let i = -1; i <= 1; i++) {
                    for (let j = -1; j <= 1; j++) {
                        if (i == 0 && j == 0) continue;
                        let a = x + i;
                        let b = y + j;

                        if (this.board.in(a, b) && (this.board.isEmpty(a, b) || this.board.isBlack(a, b))) {
                            moves.push([a, b]);
                        }
                    }
                }
            } else {
                for (let i = -1; i <= 1; i++) {
                    for (let j = -1; j <= 1; j++) {
                        if (i == 0 && j == 0) continue;
                        let a = x + i;
                        let b = y + j;
                        
                        if (this.board.in(a, b) && (this.board.isEmpty(a, b) || this.board.isWhite(a, b))) {
                            moves.push([a, b]);
                        }
                    }
                }
            }
        }
        
        return moves;
    }

    highlight() {
        Board.highlightPiece(this.x, this.y);
    }

    toString() {
        return `${this.col[6]} ${Object.keys(piece)[this.type]} {x=${this.x}, y=${this.y}}`;
    }
}

class Board {
    constructor() {
        this.board = [
            [null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null]
        ];

        this.Bpieces = [
            new Piece(piece.ROOK, player.BLACK, this, 3, 4),
            new Piece(piece.ROOK, player.BLACK, this, 7, 0),
            new Piece(piece.KNIGHT, player.BLACK, this, 1, 0),
            new Piece(piece.KNIGHT, player.BLACK, this, 6, 0),
            new Piece(piece.BISHOP, player.BLACK, this, 2, 2),
            new Piece(piece.BISHOP, player.BLACK, this, 5, 0),
            new Piece(piece.QUEEN, player.BLACK, this, 7, 3),
            new Piece(piece.KING, player.BLACK, this, 4, 0)
        ];
        
        for (let i = 0; i < 8; i++) {
            this.Bpieces.push(new Piece(piece.PAWN, player.BLACK, this, i, 1));
        }
        
        this.Wpieces = [
            new Piece(piece.ROOK, player.WHITE, this, 4, 4),
            new Piece(piece.ROOK, player.WHITE, this, 7, 7),
            new Piece(piece.KNIGHT, player.WHITE, this, 1, 7),
            new Piece(piece.KNIGHT, player.WHITE, this, 6, 7),
            new Piece(piece.BISHOP, player.WHITE, this, 2, 5),
            new Piece(piece.BISHOP, player.WHITE, this, 5, 7),
            new Piece(piece.QUEEN, player.WHITE, this, 3, 5),
            new Piece(piece.KING, player.WHITE, this, 4, 7)
        ];
        
        for (let i = 0; i < 8; i++) {
            this.Wpieces.push(new Piece(piece.PAWN, player.WHITE, this, i, 6));
        }
        let loaded = 32;
        let b = this;
        for (let p of this.Bpieces) {
            p.image.onload = function() {
                if (--loaded == 0) {
                    b.draw();
                }
            }
        }

        for (let p of this.Wpieces) {
            p.image.onload = function() {
                if (--loaded == 0) {
                    b.draw();
                }
            }
        }

        this.turn = player.WHITE;
        this.turnNumber = 0;
        this.selected = undefined;
        this.moves = undefined;
    }

    get(x, y) {
        return this.board[y][x];
    }
    
    set(x, y, p) {
        this.board[y][x] = p;
    }

    in(x, y) {
        return x >= 0 && x <= 7 && y >= 0 && y <= 7;
    }

    isEmpty(x, y) {
        return this.board[y][x] == null;
    }

    isBlack(x, y) {
        return this.board[y][x] != null && 
            this.board[y][x].col == player.BLACK;
    }

    isWhite(x, y) {
        return this.board[y][x] != null && 
            this.board[y][x].col == player.WHITE;
    }


    makeMove(fromX, fromY, toX, toY) {
        let p = this.get(fromX, fromY);

        if (p.col == this.turn) {
            let to = this.get(toX, toY);
            if (to) {
                to.image.style.opacity = 0;
                // to.image.style.display = 'none';
            }
            p.move(toX, toY);

            this.turnNumber++;
            this.turn = Object.values(player)[this.turnNumber%2];

            this.selected = undefined;
            this.moves = undefined;

            this.draw();
        }
    }

    isInCheck(col) {
        if (col == player.WHITE) {
            let wk = this.Wpieces[7];
            for (let p of this.Bpieces) {
                for (let m of p.getMoves()) {
                    if (m[0] == wk.x && m[1] == wk.y) {
                        return true;
                    }
                }
            }
        } else {
            let bk = this.Bpieces[7];
            for (let p of this.Wpieces) {
                for (let m of p.getMoves()) {
                    if (m[0] == bk.x && m[1] == bk.y) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    static highlightRoute(x, y) {
        document.getElementById(`${x}_${y}_overlay`).classList.add`route`;
    }

    static highlightPiece(x, y) {
        document.getElementById(`${x}_${y}_overlay`).classList.add`selected`;
    }

    highlight(x, y) {
        if (this.selected && this.in(...this.selected)) {
            let p = this.get(...this.selected);
            for (let m of p.getMoves()) {
                Board.highlightRoute(...m);
            }
            p.highlight();
        }
    }

    draw() {
        document.querySelectorAll('.selected').forEach(i => i.classList.remove('selected'));
        document.querySelectorAll('.route').forEach(i => i.classList.remove('route'));
        this.highlight();
        console.log('in check\n\tblack: ' + this.isInCheck(player.BLACK) + '\n\twhite: ' + this.isInCheck(player.WHITE));
    }
}

const b = new Board();

board.onmouseup = function(e) {
    let offset = board.getBoundingClientRect();
    let pixelX = e.pageX - offset.left;
    let pixelY = e.pageY - offset.top;
    let tileX = Math.floor(pixelX / 64);
    let tileY = Math.floor(pixelY / 64);

    if (b.selected) {
        let p = b.get(...b.selected);
        for (let pos of b.moves) {
            if (pos[0] == tileX && pos[1] == tileY) {
                b.makeMove(...b.selected, ...pos);
                return;
            }
        }
        if ((b.selected[0] == tileX && b.selected[1] == tileY) || b.isEmpty(tileX, tileY)) {
            b.selected = undefined;
            b.moves = undefined;
            
            b.draw();
            return;
        }
    }

    if (!b.isEmpty(tileX, tileY)) {
        let p = b.get(tileX, tileY);
        if (b.turn == p.col) {
            b.selected = [tileX, tileY];
            b.moves = p.getMoves();

            b.draw();
        }
    }
}



var socket = io('http://localhost');
socket.on('news', function (data) {
    console.log(data);
    socket.emit('my other event', { my: 'data' });
});